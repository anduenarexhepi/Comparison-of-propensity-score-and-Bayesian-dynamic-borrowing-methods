PS_Match <- function(n_sim=1000, sim_data){

  TE <- rep(NA, n_sim)

  matched <- rep(NA, n_sim)

  CI <- matrix(NA, nrow = n_sim, ncol = 2)
  colnames(CI) <- c("Lower95","Upper95")

  for (i in 1:n_sim){

    df <- as.data.frame(sim_data[[i]])

    # logit(PS) estimation by using ALL (current and historical) data
    df$logitPS <- MatchIt::matchit(formula = Z ~ age,
                                   data = df, method = NULL,
                                   distance = "glm",
                                   link = "linear.logit")$distance

    # only current control and historical control data
    # --> only treatment == 0
    control_data <- df[df$treatment==0,]

    # Now ONLY Matching, match historical control (Z=0, T=0) to
    # current control (Z=1, T=0) patients,
    # use precalculated logit(PS)
    # discard = "control" removes historical unmatched patients
    # since Z=0 contains historical data
    cd.out <- MatchIt::matchit(formula = Z ~ age,
                               data = control_data, method = "nearest",
                               distance = control_data$logitPS,
                               discard = "control", ratio=1,
                               caliper = 0.2,
                               reestimate = FALSE)
    mdata <- MatchIt::match.data(cd.out, group = "all",
                                 distance = "logit_PS")
    mdata <- rbind(df[df$Z==1&df$treatment==1,1:7],mdata[,1:7])
    TE[i] <- with(data = mdata[mdata$treatment == 1, ],
                  mean(Y)) - with(data = mdata[mdata$treatment == 0,],
                                  mean(Y))
    #mean of outcome  of current treated patients -
    #mean of outcome of current & historical matched placebo patients

    matched[i] <- nrow(mdata[mdata$Z==0 & mdata$treatment == 0, ])
    #historical (control)

    m <- nrow( mdata[mdata$treatment == 1, ] )
    # number of active treatment patients
    n <- nrow( mdata[mdata$treatment == 0, ] )
    # number of control patients
    sT_var <- with(data = mdata[mdata$treatment == 1, ], var(Y))
    # sample variance of Y of active patients
    sC_var <- with(data = mdata[mdata$treatment == 0, ], var(Y))
    # sample variance of Y of control patients
    S <- sqrt( ( (m-1)*sT_var + (n-1)*sC_var )/( m+n-2 ) )
    aux <- sqrt((1/m)+(1/n))

    t <- qt(0.975, m+n-2)

    CI[i, 1]<-TE[i]-t*S*aux
    CI[i, 2]<-TE[i]+t*S*aux

  }

  ATE = mean(TE)
  e.var = (n_sim/(n_sim-1))*mean((TE-ATE)^2)
  bias = ATE - (-2)
  mse = mean((TE-(-2))^2)
  coverage = mean( CI[,1] <= (-2) & CI[,2] >= (-2) )
  n_hist = mean(matched)
  res <- c(ATE, bias, e.var, mse, coverage, n_hist)
  return(res)

}

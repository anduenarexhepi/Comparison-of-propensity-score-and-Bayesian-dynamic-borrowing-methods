## Estimate propensity score via logistic regression
ps_logistic<-function(formula=as.formula(""), data=data.frame()){
  # formula should be entered as one would do for glm
  model<-glm(formula=formula, family = binomial(link = "logit"),
             data=data)
  ptreat<-predict(model, type="response")
  return(ptreat)
}

## Calculates the overlapping coefficient between
## two distributions
metric_ovl <- function(cov0, cov1) {
  # cov0 is a numeric vector of propensity scores for
  # external study subjects
  # cov1 is a numeric vector of propensity scores for
  # current study subjects
  cov <- c(cov0, cov1)
  if (length(unique(cov)) <= 10) {
    all_x <- c(rep(0, length(cov0)), rep(1, length(cov1)))
    pt    <- apply(prop.table(table(cov, all_x), 2), 1, min)

    return(sum(pt))
  }

  mn <- min(cov);
  mx <- max(cov);

  f1 <- approxfun(density(cov1, from = mn, to = mx, bw = "nrd"));
  # density computes kernel density estimates; from and to indicate
  # the left and right-most points of the grid at which the density
  # is to be estimated
  f0 <- approxfun(density(cov0, from = mn, to = mx, bw = "nrd"));
  # approxfun performs linear interpolation of the given data points

  fn <- function(x)
    pmin(f1(x), f0(x))

  s <- try(integrate(fn, lower = mn, upper = mx,
                     subdivisions = 500)$value)

  ifelse(inherits(s, "try-error"), NA, s)
  # the overlapping coefficient value is returned
}

## Stratifies the data based on quantiles of the esitmated PS of
# current study subjects such that the number of current subjects
# is the same across strata
stratify<-function(ps=numeric(), group=numeric(), nstrata=5){
  strata<-numeric(length(ps))

  q<-quantile(ps[which(group==1)],
              probs=seq(0, 1, length.out=(nstrata+1)))
  ## Constructs the bounds/cut points for each strata

  for(i in 1:length(ps)){
    for(j in 1:(length(q)-1)){
      if(j==1){ ## ensures the current study subject
        ##with the smallest propensity score is included
        if(ps[i] >= q[j] & ps[i] <= q[j+1]){
          strata[i]<-j
        }
      }else{
        if(ps[i] > q[j] & ps[i] <= q[j+1]){
          strata[i]<-j
        }
      }
    }
  }
  return(list(strata=strata, q=q))
  # strata is a vector indicating which stratum each subject
  # falls in
  # q provides the bounds of the strata
}

## Estimates overlapping coefficients and determines number of
## current and external study subjects within each stratum
get_ovl<-function(ps=numeric(), group=numeric(), strata=numeric(),
                  nstrata=5){
  out<-matrix(NA, nrow=nstrata, ncol=3)
  rownames(out)<-as.character(1:nstrata)
  colnames(out)<-c("N0", "N1", "OvlC")

  for(i in 1:nstrata){
    n0<-sum(strata==i & group==0)
    n1<-sum(strata==i & group==1)
    ps0<-ps[which(strata==i & group==0)]
    ps1<-ps[which(strata==i & group==1)]
    out[i,]<-c(n0, n1, metric_ovl(cov0=ps0, cov1=ps1))
    ## Each row of out is a stratum; N0 is the number of external
    ## study subjects in each stratum, N1 is the number of current
    ##study subjects in each stratum; OvlC provides the overlapping
    ## coefficient in each stratum
  }
  return(out)
}

#Obtaining summary statistics for each external data sets within
#each stratum
sumstat<-function(stratum=data.frame()){ ##input is the data for
  ##one stratum only
  nStu<-unique(stratum[which(stratum$Study>0),]$Study)
  ## vector of studies observed in the particular stratum
  Y_bar<-numeric()
  sigma<-numeric()
  n<-numeric()
  Stu<-numeric()

  for(i in nStu){ ## We obtain summary statistics for the external
    ## data sources present in this stratum
    if(sum(stratum$Z==0 & stratum$Study==i)==1){
      ## Cannot obtain a sd/se estimate with just one observation
      next
    }

    Stu<-c(Stu, i )

    Y_bar<-c(Y_bar,
             mean(stratum[which(stratum$Z==0 &
                                  stratum$Study==i),]$Y))
    ## sample mean for external study i
    n<-c(n, sum(stratum$Z==0 & stratum$Study==i))
    ## number of subjects in external study i

    if(sum(stratum$Z==0 & stratum$Study==i)<=10){
      sigma<-c(sigma,
               sd(stratum[which(stratum$Z==0 &
                                  stratum$Study==i),]$Y))
      ## sample standard deviation for external study i
    }else{
      # RSE from fitting the outcome on age by using external
      # study i
      res <- lm(Y ~ age, data = stratum[which(stratum$Z == 0 &
                                          stratum$Study == i), ])
      RSS <- c(crossprod(res$residuals))
      sigma <- c(sigma,  sqrt( RSS / res$df.residual ))
    }

  }

  return(list(Y_bar=Y_bar, sigma=sigma, n=n, nStu=Stu))
}

## Constructs a MAP prior distribution based on external data
MAPprior<-function(stratum = data.frame(), sumstat,
                   nStu=numeric(), iter=2000, burn = 1000,
                   chains=1, thin=1, k=1, t=1){
  ## In our proposed approach, a MAP prior is constructed
  ## separately for each stratum
  ## stratum is the data for this stratum
  ## sumstat is the list returned by the sumstat function with
  ## summary statistics and sample sizes of each external study
  ## nStu is a vector of external study numbers returned by the
  ## sumstat function
  data<-data.frame(Study = nStu, n=sumstat$n, y=sumstat$Y_bar,
                   y.se = sumstat$sigma/sqrt(sumstat$n))
  ## Format data to input in gMAP function

  ## For continuous outcome
  map_mcmc<-RBesT::gMAP(cbind(y, y.se)~1 | Study,
             data=data, weight = n,
             family=gaussian,
             beta.prior = cbind(0,100*mean(sumstat$sigma)),
             tau.dist="HalfNormal",
             tau.prior=cbind(0, k*t),
             iter=iter, warmup=burn, chains = chains, thin = thin,
             cores = 2)

  map_normmix<-RBesT::automixfit(map_mcmc) ## Mixture of normals

  map_robust <- RBesT::robustify (map_normmix, weight=0.2)
  ## Add robust component to the mixture
  return(list(map_mcmc=map_mcmc, normmix=map_normmix, robust=map_robust))
  ## The original gMAP object, normal mixture approximation,
  ## and the robust MAP priors are returned
}

# This function is directly copied from the source code,
# getAnywhere(uisd.default)
uisdd <- function (n, sigma, sigma2 = sigma^2, labels = NULL,
                   individual = FALSE,
                   ...)
{
  stopifnot(length(n) == length(sigma2), all(is.finite(n)),
            all(is.finite(sigma2)), all(n > 0), all(sigma2 > 0),
            (!individual) | ((length(labels) == 0) ||
                            (length(labels) ==length(sigma2))))
  if (individual) {
    if (!is.character(labels))
      labels <- as.character(labels)
    result <- sqrt(n * sigma2)
    names(result) <- labels
  }
  else {
    result <- sqrt(sum(n)/sum(1/sigma2))
  }
  return(result)
}

## This approach employs an assumed level of heterogeneity for
## specifying the hyperprior on tau (instead of targeting some
## target prior ESS)
## Could be based on belief regarding how heterogeneous the
## external data sets are
uisd_t<-function(strata = list(), sumstat.list=list(), nstrata=5,
                 iter=2000, burn=1000, chains = 1, thin=1,
                 k=numeric(), hetLevel="small",
                 ess_tar=numeric()){
  ## strata consists of a list where each element is a data frame
  ## corresponding to a single stratum
  ## sumstata.list is a list where each element contains the summary
  ## statistics for one stratum--list returned from sumstat function
  uisd<-numeric(length = nstrata)

  for(i in 1:nstrata){
    uisd[i]<-uisdd(n = sumstat.list[[i]]$n,
        sigma = sumstat.list[[i]]$sigma/sqrt(sumstat.list[[i]]$n))
    ## calculates the unit information standard deviation based on
    ## external data in each stratum
  }

  if(hetLevel == "small"){
    t<-uisd/32
  }else if(hetLevel == "moderate"){
    t<-uisd/16
  }else if(hetLevel == "substantial"){
    t<-uisd/8
  }else if(hetLevel == "large"){
    t<-uisd/4
  }

  MAPpriors<-vector(mode = "list", length = nstrata)
  ESS<-numeric(length=nstrata)

  for(i in 1:nstrata){
    temp <- MAPprior(stratum = strata[[i]],
                     sumstat = sumstat.list[[i]],
                     nStu = sumstat.list[[i]]$nStu,
                     iter = iter, burn = burn,
                     chains = chains, thin=thin,
                     k = k[i], t=t[i])
    ## Constructs MAP prior based on the assumed degree of
    ## heterogeneity
    MAPpriors[[i]] <- temp$robust
    ESS[i] <- RBesT::ess(MAPpriors[[i]], "elir")
    ## Calculates the ESS corresponding to the robust MAP prior
  }

  # sum(prior ESS) should be <= ess_tar, if not, then the sd of
  #prior components (of all strata) get inflated with inflation
  #parameter ip
  if(sum(ESS) > ess_tar){
    if(sum(ESS) >= 295){
      ip <- 1.8
    } else{
      ip <- 1.5
    }
  } else{
    ip <- 1
  }

  while(sum(ESS) > ess_tar){
    ip <- ip + 0.1
    for(i in 1:nstrata){
      temp <- MAPprior(stratum = strata[[i]],
                       sumstat = sumstat.list[[i]],
                       nStu = sumstat.list[[i]]$nStu,
                       iter = iter, burn = burn,
                       chains = chains, thin=thin,
                       k = k[i], t=t[i])
      MAPpriors[[i]] <- temp$robust
      MAPpriors[[i]][3,1:ncol(MAPpriors[[i]])] <-
        MAPpriors[[i]][3,1:ncol(MAPpriors[[i]])]*ip
      ESS[i] <- RBesT::ess(MAPpriors[[i]], "elir")
    }
  }

  return(list(MAPpriors=MAPpriors, ESS = ESS, t=t, ip=ip))

}

## Obtain posterior distributions of the average outcome
## under treatment and under control as well as the
## treatment effect (difference)
strata_post_2<-function(MAPpriors = list(), nstrata= 5,
                        curr_treated = data.frame(),
                        curr_controls = data.frame(),
                        post_draws=1000){
  ## Each element of MAP priors is the robust prior constructed
  ## from external data in a strata
  ## curr_treated consists of data on treated subjects in the
  ## current trial or study
  ## curr_controls consists of data on control/placebo subjects
  ## in the current trial or study
  post_treated<-vector(mode = "list", length = nstrata)
  ## List to store posterior distributions of outcome under
  ##treatment for all strata
  post_control<-vector(mode = "list", length = nstrata)
  ## List to store posterior distributions  of outcome under
  ## control for all strata
  ## The following stores the samples/draws from the posterior
  ## distributions of the mean outcomes for all strata
  ## (each column is a separate stratum)
  postsamp_treated<-matrix(NA, nrow=post_draws, ncol=nstrata)
  colnames(postsamp_treated)<-paste0("S", 1:nstrata)
  postsamp_control<-matrix(NA, nrow=post_draws, ncol=nstrata)
  colnames(postsamp_control)<-paste0("S", 1:nstrata)

  posterior_ESS <- vector(length = nstrata)

  for(i in 1:nstrata){
    weak_prior <- RBesT::mixnorm(c(1,summary(MAPpriors[[i]])[1],1),
                                 sigma=MAPpriors[[i]][3,
                                ncol(MAPpriors[[i]])],
                                param = 'mn')
    ## effective sample size of this prior is 1;
    ##weak prior/non-informative prior is used so that the data
    ## on treated subjects in the current trial drives the
    ##posterior inference

    post_treated[[i]]<-
      RBesT::postmix(weak_prior,
            data = curr_treated[which(curr_treated$strata==i),]$Y)
    # Update prior with current treatment group data to obtain
    # posterior distribution of parameter under treated
    postsamp_treated[,i] <- RBesT::rmix(mix = post_treated[[i]],
                                        n=post_draws)
    ## Sampling from posterior

    post_control[[i]] <-
      RBesT::postmix(MAPpriors[[i]],
             data = curr_controls[which(curr_controls$strata==i),]$Y)
    # Update prior with current control group data to obtain
    # posterior distribution of parameter under control
    postsamp_control[,i]<-
      RBesT::rmix(mix = post_control[[i]], n=post_draws)
    ## Sampling from posterior
    posterior_ESS[i] <- RBesT::ess(post_control[[i]], method = "elir")

  }

  post_TE<-postsamp_treated-postsamp_control ## Treatment effect
  ##estimate as a difference of mean outcome under treatment and
  ##mean outcome under the control

  return(list(post_TE, posterior_ESS))
}

## The following function conducts one implementation of the
## within-stratum MAP prior approach that specifies the hyperprior
## on tau according an assumed level of heterogeneity;
## may be used for simulation or data analysis
one_sim_sep_strata_het_2<-function(data = data.frame(),
                                   covariates=character(),
                                   nstrata = 5, iter=2000,
                                   burnin = 1000, chains=1,
                                   thin=1, heterogeneity="small",
                                   ess_tar=100){

  all<-data
  f<-paste0("Z ~ ", covariates[1])
  if(length(covariates)>=2){
    for(i in 2:length(covariates)){
      f<-paste0(f, " + ", covariates[i])
    }
  }

  ## Estimates propensity scores using logistic regression
  all$ps<-ps_logistic(formula = as.formula(f), data = all)

  stratifying<-stratify(ps = all$ps, group = all$Z,
                        nstrata = nstrata)

  all$strata<-stratifying$strata

  # If no or only one historical subject (in each historical study)
  # allocated to last stratum, then merge it with the one before
  if ( sum(all[which(all$Study==1),]$strata==nstrata) <= 1 &
       sum(all[which(all$Study==2),]$strata==nstrata) <= 1 &
       sum(all[which(all$Study==3),]$strata==nstrata) <= 1) {
    all[which(all$strata==nstrata),]$strata = (nstrata-1)
    nstrata <- nstrata - 1
    if ( sum(all[which(all$Study==1),]$strata==nstrata) <= 1 &
         sum(all[which(all$Study==2),]$strata==nstrata) <= 1 &
         sum(all[which(all$Study==3),]$strata==nstrata) <= 1) {
      all[which(all$strata==nstrata),]$strata = (nstrata-1)
      nstrata <- nstrata - 1
    }
    else {
      nstrata <- nstrata
    }
  } else {
    nstrata <- nstrata
  }

  boundsE1<-quantile(all[which(all$Z==1),]$ps, probs=c(0,1))

  # Trim external subjects whose PS are outside range of
  # current subjects' PS
  subset<-all[which(all$ps>= boundsE1[1] & all$ps <= boundsE1[2]),]

  tab_OvlC<-get_ovl(ps=subset$ps, group=subset$Z,
                    strata=subset$strata, nstrata=nstrata)

  R<-tab_OvlC[,3]
  r_ref<-median(R)
  k<-r_ref/R

  strata.list<-vector(mode = "list", length = nstrata)
  sumstat.list<-vector(mode = "list", length = nstrata)

  for(i in 1:nstrata){
    strata.list[[i]]<-subset[which(subset$strata==i),]
    sumstat.list[[i]]<-sumstat(stratum = strata.list[[i]])
  }

  MAPt<-uisd_t(strata = strata.list, sumstat.list = sumstat.list,
               nstrata = nstrata, iter = iter, burn = burnin,
               chains = chains, thin = thin, k = k,
               hetLevel = heterogeneity, ess_tar = ess_tar)

  totalESS<-tab_OvlC[,2] + MAPt$ESS

  weight_strata <- R/sum(R)

  post<-
    strata_post_2(MAPpriors = MAPt$MAPpriors, nstrata=nstrata,
    curr_treated = subset[which(subset$Z==1 & subset$treatment==1),],
    curr_controls = subset[which(subset$Z==1 & subset$treatment==0),],
    post_draws=10000)

  posterior <- post[[1]]
  weighted <- sweep(posterior, MARGIN = 2, weight_strata, `*`)
  overall_post <- rowSums(weighted)

  CrI <- quantile(overall_post, probs=c(.025, .975))

  ncc <- nrow(subset[which(subset$Z == 1 & subset$treatment == 0), ])
  #number of current control patients
  post_ESS_adj <- sum(post[[2]]) - ncc

  return(list(TE=mean(overall_post), CrI=CrI , totalESS=totalESS,
              R=R, weight_strata=weight_strata, n1=tab_OvlC[,2],
              t=MAPt$t, priorESS=MAPt$ESS, ip=MAPt$ip,
              sumstat.list=sumstat.list, nstrata=nstrata,
              post_ESS_adj=post_ESS_adj))

}

PS_stratified_MAP_heterogeneity_2 <- function (sim_data_i){

  temp <- one_sim_sep_strata_het_2(data = sim_data_i,
                                   covariates = c("age"),
                                   nstrata = 5, iter=12000,
                                   burnin=2000, chains = 2,
                                   thin = 1,
                                   heterogeneity="moderate",
                                   ess_tar = 100)

  nstrata <- temp$nstrata

  TE_estimate <- temp$TE
  lower95 <- as.numeric(temp$CrI[1])
  upper95 <- as.numeric(temp$CrI[2])

  return(
    list(
      priorESS = temp$priorESS,
      TE       = TE_estimate,
      lower95  = lower95,
      upper95  = upper95,
      ip       = temp$ip,
      post_ESS_adj = temp$post_ESS_adj
    )
  )
}

chunkVector <- function (x, n_chunks) {
  if (n_chunks <= 1) {
    chunk_list <- list(x)
  } else {
    chunk_list <- unname(split(x, cut(seq_along(x),
                                      n_chunks,
                                      labels = FALSE)))
  }
  return (chunk_list)
}


PS_MAP_2 <- function(n_sim = n_sim, sim_data){

  chunks_outer <- chunkVector(seq_len(n_sim),
                              getDoParWorkers())

  PS_MAP_Het_list <- foreach(k = chunks_outer, .combine = c) %dorng% {

    ## parallelization within worker node over cpus
    chunks_inner <- chunkVector(k, getDoParWorkers())

    foreach(i = chunks_inner, .combine = c) %dorng% {

      lapply(i, function (j) {

        PS_stratified_MAP_heterogeneity_2(sim_data_i =
                                  as.data.frame(sim_data[[j]]))

      })
    }
  }

  ATE <- mean( sapply(PS_MAP_Het_list, function(x) {x$TE}) )
  bias <- ATE - (-2)
  e.var <- (n_sim/(n_sim-1))*mean( ( sapply(PS_MAP_Het_list,
                                    function(x) {x$TE})-ATE )^2 )
  mse <- mean( (sapply(PS_MAP_Het_list, function(x) {x$TE})-(-2))^2 )
  coverage <- mean( sapply(PS_MAP_Het_list,
                      function(x) {x$lower95}) <= (-2) &
            sapply(PS_MAP_Het_list, function(x) {x$upper95}) >= (-2) )
  priorESS <- mean( sapply(PS_MAP_Het_list,
                           function(x) {sum(x$priorESS)}) )
  ip <- mean( sapply(PS_MAP_Het_list, function(x) {x$ip}) )
  postESS <- mean( sapply(PS_MAP_Het_list, function(x) {x$post_ESS_adj}) )

  res <- c(ATE, bias, e.var, mse, coverage, priorESS, ip, postESS)
  return(res)

}




dynamicBayesianBorrowing <- function (sim_data_i) {

  study <-unique(sim_data_i[which(sim_data_i$Study>0),]$Study)
  ## vector of studies observed

  Y_bar<-numeric()
  sigma<-numeric()
  n<-numeric()
  se<-numeric()

  # summary statistics from historical data for prior calculation
  for(i in 1:length(study)){

    Y_bar <- c(Y_bar,
        mean(
          sim_data_i[which(sim_data_i$Z == 0 &
                     sim_data_i$Study == i), ]$Y))
    ## sample mean for external study i
    n     <- c(n,sum(sim_data_i$Z == 0 & sim_data_i$Study == i))
    ## number of subjects in external study i

    # RSE from fitting the outcome on age by using external study i
    res <- lm(Y ~ age, data = sim_data_i[which(sim_data_i$Z == 0 &
                                        sim_data_i$Study == i), ])
    RSS <- c(crossprod(res$residuals))
    sigma <- c(sigma,  sqrt( RSS / res$df.residual ))

  }

  se    <- sigma / sqrt(n)

  sumstat <- t(as.data.frame(rbind(y = Y_bar, y.sigma = sigma, n,
                                   y.se=se, Study=study)))
  sumstat <- as.data.frame(sumstat)

  gmap             <- RBesT::gMAP(cbind(y, y.se) ~ 1 | Study,
                      data = sumstat,
                      weight = n, family = gaussian,
                      beta.prior = cbind(0, 100*mean(sumstat$y.sigma) ),
                      tau.dist = "HalfNormal",
                      tau.prior = cbind(0, mean(sumstat$y.sigma) / 8),
                      iter=12000, chains=2, thin=1)
  map              <- RBesT::automixfit(gmap)
  robust_map_prior <- RBesT::robustify(map, weight = 0.2)

  # prior ESS should be <= 100, if not,
  # then the sd of prior components get inflated
  priorESS <- RBesT::ess(robust_map_prior, "elir")
  ip <- 1 # inflation parameter; neutral
    while(priorESS > 100){
      ip <- ip + 0.1
      ncol <- ncol(robust_map_prior)
      robust_map_prior[3,1:ncol] <- robust_map_prior[3,1:ncol]*ip
      priorESS <- RBesT::ess(robust_map_prior, "elir")
    }


  #weak informative prior for active arm of current study
  weak_map_prior <-
    RBesT::mixnorm(c(1,summary(robust_map_prior)[1], 1),
                   sigma = robust_map_prior[3,ncol(robust_map_prior)],
                   param = 'mn') # ESS of 1

  #calculate posterior distribution
  posterior_treated <-
    RBesT::postmix(weak_map_prior,
                   data = sim_data_i[which(sim_data_i$Z == 1 &
                                  sim_data_i$treatment == 1), ]$Y)
  posterior_control <-
    RBesT::postmix(robust_map_prior,
                   data = sim_data_i[which(sim_data_i$Z == 1 &
                                 sim_data_i$treatment == 0), ]$Y)

  lower95 <- RBesT::qmixdiff(posterior_treated,
                             posterior_control, p=0.025)
  upper95 <- RBesT::qmixdiff(posterior_treated,
                             posterior_control, p=0.975)

  TE_estimate<- weighted.mean(w=posterior_treated[1,],
                              x=posterior_treated[2,])-
                weighted.mean(w=posterior_control[1,],
                              x=posterior_control[2,])

  ncc <- nrow(sim_data_i[which(sim_data_i$Z == 1 & sim_data_i$treatment == 0), ])
  #number of current control patients
  posterior_ESS_adj <- RBesT::ess(posterior_control, "elir") - ncc

  return (list(TE       = TE_estimate,
               priorESS = priorESS,
               lower95  = lower95,
               upper95  = upper95,
               ip       = ip,
               posterior_ESS_adj = posterior_ESS_adj
  ))

}


chunkVector <- function (x, n_chunks) {
  if (n_chunks <= 1) {
    chunk_list <- list(x)
  } else {
    chunk_list <- unname(split(x, cut(seq_along(x),
                                      n_chunks,
                                      labels = FALSE)))
  }
  return (chunk_list)
}


bayesianBorrowing <- function(n_sim = n_sim, sim_data){

  ## parallelization over worker nodes
  chunks_outer <- chunkVector(seq_len(n_sim),
                              getDoParWorkers())

  BB_list <- foreach(k = chunks_outer, .combine = c) %dorng% {

    ## parallelization within worker node over cpus
    chunks_inner <- chunkVector(k, getDoParWorkers())

    foreach(i = chunks_inner, .combine = c) %dorng% {

      lapply(i, function (j) {

        dynamicBayesianBorrowing(sim_data_i =
                                   as.data.frame(sim_data[[j]]))

      })
    }
  }

  ATE <- mean( sapply(BB_list, function(x) {x$TE}) )
  bias <- ATE - (-2)
  e.var <- (n_sim/(n_sim-1))*mean( ( sapply(BB_list,
                                      function(x) {x$TE})-ATE )^2 )
  mse <- mean( (sapply(BB_list, function(x) {x$TE})-(-2))^2 )
  coverage <- mean( sapply(BB_list,
                           function(x) {x$lower95}) <= (-2) &
                      sapply(BB_list,
                             function(x) {x$upper95}) >= (-2) )
  priorESS <- mean( sapply(BB_list, function(x) {x$priorESS}) )
  ip <- mean( sapply(BB_list, function(x) {x$ip}) )
  postESS <- mean( sapply(BB_list, function(x) {x$posterior_ESS_adj}) )

  res <- c(ATE, bias, e.var, mse, coverage, priorESS, ip, postESS)
  return(res)

}




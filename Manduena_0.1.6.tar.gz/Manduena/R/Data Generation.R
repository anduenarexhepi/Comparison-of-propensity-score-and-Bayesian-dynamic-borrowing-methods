data_simulation_oht <- function(n_sim=1000,
                                age_m_historical  = 60,
                                age_sd_historical = 10,
                                bmi_m_historical  = 25,
                                bmi_sd_historical = 3){

  n_current_treated <- 200
  n_current_control <- 100

  age_m_current  <- 50
  age_sd_current <- 10
  bmi_m_current  <- 25
  bmi_sd_current <- 3

  n_historical_control <- 1000

  age_m_historical  <- age_m_historical
  age_sd_historical <- age_sd_historical
  bmi_m_historical  <- bmi_m_historical
  bmi_sd_historical <- bmi_sd_historical

  epsilon_sd <- 20

  trt   <- c(rep(1, n_current_treated),
             rep(0, n_current_control + n_historical_control))
  Z     <- c(rep(1, n_current_treated + n_current_control),
             rep(0, n_historical_control))
  study <- c(rep(-1, n_current_treated + n_current_control),
             rep(1, n_historical_control))

  sim_data <- vector(mode = "list", length = n_sim)

  for (i in 1:n_sim){

    ## current

    age_current_treated <- rnorm(n_current_treated,
                                 mean = age_m_current,
                                 sd = age_sd_current)
    age_current_control <- rnorm(n_current_control,
                                 mean = age_m_current,
                                 sd = age_sd_current)

    bmi_current_treated <- rnorm(n_current_treated,
                                 mean = bmi_m_current,
                                 sd = bmi_sd_current)
    bmi_current_control <- rnorm(n_current_control,
                                 mean = bmi_m_current,
                                 sd = bmi_sd_current)

    ## historical

    age_historical_control <- rnorm(n_historical_control,
                                    mean = age_m_historical,
                                    sd = age_sd_historical)
    bmi_historical_control <- rnorm(n_historical_control,
                                    mean = bmi_m_historical,
                                    sd = bmi_sd_historical)

    ## Outcome - Blood pressure via linear model

    age <- c(age_current_treated, age_current_control,
             age_historical_control)
    bmi <- c(bmi_current_treated, bmi_current_control,
             bmi_historical_control)

    epsilon <- rnorm(n_current_treated + n_current_control +
                       n_historical_control,
                     mean = 0, sd = epsilon_sd)

    ## index 1:200: current trt, 201:300 current control,
    ## 301:1300 hist control
    outcomes <-  150 + 0.1 * (age-50) + 0.3 *  (bmi-25) +
      -2 * trt + epsilon

    sim_data[[i]] <- cbind(age, bmi, Z, treatment = trt,
                           Study = study, Y = outcomes)

  }

  return(sim_data)

}


data_simulation_mht <-
  function(n_sim=1000,  n_historical_control = c(300,300,300),
           age_m_historical  = c(50,50,50),
           age_sd_historical = c(10,10,10),
           bmi_m_historical  = c(25,25,25),
           bmi_sd_historical = c(3,3,3)){

  n_current_treated <- 200
  n_current_control <- 100

  age_m_current  <- 50
  age_sd_current <- 10
  bmi_m_current  <- 25
  bmi_sd_current <- 3

  n_historical_control <- n_historical_control

  age_m_historical  <- age_m_historical
  age_sd_historical <- age_sd_historical
  bmi_m_historical  <- bmi_m_historical
  bmi_sd_historical <- bmi_sd_historical

  epsilon_sd <- 20

  trt   <- c(rep(1, n_current_treated),
             rep(0, n_current_control + sum(n_historical_control)))
  Z     <- c(rep(1, n_current_treated + n_current_control),
             rep(0, sum(n_historical_control)))
  study <- c(rep(-1, n_current_treated + n_current_control),
             rep(1, n_historical_control[1]),
             rep(2, n_historical_control[2]),
             rep(3, n_historical_control[3]))

  sim_data <- vector(mode = "list", length = n_sim)

  for (i in 1:n_sim){

    ## current

    age_current_treated <- rnorm(n_current_treated,
                                 mean = age_m_current,
                                 sd = age_sd_current)
    age_current_control <- rnorm(n_current_control,
                                 mean = age_m_current,
                                 sd = age_sd_current)

    bmi_current_treated <- rnorm(n_current_treated,
                                 mean = bmi_m_current,
                                 sd = bmi_sd_current)
    bmi_current_control <- rnorm(n_current_control,
                                 mean = bmi_m_current,
                                 sd = bmi_sd_current)

    ## historical

    age_historical_control_1 <- rnorm(n_historical_control[1],
                                      mean = age_m_historical[1],
                                      sd = age_sd_historical[1])
    age_historical_control_2 <- rnorm(n_historical_control[2],
                                      mean = age_m_historical[2],
                                      sd = age_sd_historical[2])
    age_historical_control_3 <- rnorm(n_historical_control[3],
                                      mean = age_m_historical[3],
                                      sd = age_sd_historical[3])
    age_historical_control <- c(age_historical_control_1,
                                age_historical_control_2,
                                age_historical_control_3)

    bmi_historical_control_1 <- rnorm(n_historical_control[1],
                                    mean = bmi_m_historical[1],
                                    sd = bmi_sd_historical[1])
    bmi_historical_control_2 <- rnorm(n_historical_control[2],
                                      mean = bmi_m_historical[2],
                                      sd = bmi_sd_historical[2])
    bmi_historical_control_3 <- rnorm(n_historical_control[3],
                                      mean = bmi_m_historical[3],
                                      sd = bmi_sd_historical[3])
    bmi_historical_control <- c(bmi_historical_control_1,
                                bmi_historical_control_2,
                                bmi_historical_control_3)

    ## Outcome - Blood pressure via linear model

    age <- c(age_current_treated, age_current_control,
             age_historical_control)
    bmi <- c(bmi_current_treated, bmi_current_control,
             bmi_historical_control)

    epsilon <- rnorm(n_current_treated + n_current_control +
                       sum(n_historical_control),
                     mean = 0, sd = epsilon_sd)

    ## index 1:200: current trt, 201:300 current control,
    ## 301:1200 hist control (a 300 per hist. study)
    outcomes <-  150 + 0.1 * (age-50) + 0.3 *  (bmi-25) +
      -2 * trt + epsilon

    sim_data[[i]] <- cbind(age, bmi, Z, treatment = trt,
                           Study = study, Y = outcomes)

  }

  return(sim_data)

}
